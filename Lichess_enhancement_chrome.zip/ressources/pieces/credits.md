**Chess.com**
3d_chesskid
3d_plastic
3d_staunton
3d_wood
8_bit
alpha
bases
blindfold
book
bubblegum
cases
classic
club
condal
dash
game_room
glass
gothic
graffiti
icy_sea
light
lolz
marble
maya
metal
modern
nature
neo
neo_wood
neon
newspaper
ocean
sky
space
tigers
tournament
vintage
wood

**PureBlue** https://userstyles.org/users/374749
christmas
royale

**thechessfoundry** https://thechessfoundry.com/
iowa
falcon
oslo
chicago

**bakkouz** https://userstyles.org/users/340923
pokemon
random

**Szymon Siwak** https://userstyles.org/users/399590
wehrmacht_soviet

**RainbowDashie** https://userstyles.org/users/733076
pony

**Arcticpenguin** https://userstyles.org/users/301649
penguin

**Anonymer Mensch** https://userstyles.org/users/629256
sea
nyc

**Pawel Kacprzak** https://userstyles.org/users/899252
chessvision