**Chess.com**
8_bit
bases
blue
brown
bubblegum
burled_wood
dark_wood
dash
glass
graffiti
green
icy_sea
light
lolz
marble
metal
neon
newpaper
orange
overlay
parchment
purple
red
sand
sky
stone
tan
tournament
translucent
walnut

**PureBlue** https://userstyles.org/users/374749
christmas
christmas_alt

**Anonymer Mensch** https://userstyles.org/users/629256
sea