<center>![Lichess enhancement logo](https://image.noelshack.com/fichiers/2020/52/7/1609025586-lichess-chess-logo.png)</center>

If you want to talk with me: **Khmer vert (Duck/M)#3627** [Echecs 18-25 (french)](https://discord.gg/5AzNCEGNRW)

PS:The script may have performance issues at the end of games so it may be better to avoid bullet games (especially on Firefox).
